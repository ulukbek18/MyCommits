const knightContainer=document.getElementById('heroDavion')
const bossContainer=document.getElementById('heroBoss')


class Hero{
    constructor(name,hp,mana, maxHealth,attack,armor){
        this.name=name
        this.hp=hp
        this.mana=mana
        this.maxHealth=maxHealth
        this.attack=attack
        this.armor=armor
    }
}

class Knight extends Hero{
    // constructor (name,hp,mana,attack,armor){
    //     super(name,hp,mana,attack,armor)
    // }
}
class Boss extends Hero{
}

const knight=new Hero('knight',1000,200,2000,100,5)
const boss=new Hero('Roshan',5000,0,0,50)

function displayStats(Hero){
    let empty="";
    Object.keys(Hero).forEach((key)=>{
        empty +=`
        <div class = 'stats'>
        <h2>${key}</h2>
        <h2>:${Hero[key]}</h2>
        </div>`;
    });
    return empty;
}


function updateStats() {
    knightContainer.innerHTML = displayStats(knight);
    bossContainer.innerHTML = displayStats(boss);
}
updateStats();



function knightAttack(){
    boss.hp=boss.hp-knight.attack
    if (boss.hp===0){
        alert('Knight wins')
    }
    console.log(boss.hp)
    updateStats()
}
function bossAttack(){
    knight.hp=knight.hp-boss.attack
    if (knight.hp<0){
        alert ('Roshan wins')
    }
    updateStats()
}

function heal(){
    const knightheal=knight.hp+100
    if(knight.hp <knight.maxHealth){
        knight.hp=knightheal
    } else if(knight.hp>knight.maxHealth){
        return
    }
    updateStats()
}

function toShield(){
    const knightshield=knight.armor+1
    if(knight.armor<=1){
        knight.armor=knightshield
    } else if(knight.armor>1){
        return
    }
    updateStats()
}

function toUltimate(){
    boss.hp=boss.hp-knight.attack*3
    const manausage=knight.mana-50
    if (knight.mana>50){
        knight.mana=manausage
    }
    updateStats()
}

function rage(){
   knight.hp=knight.hp+knight.armor-boss.attack*2
   updateStats()
}
